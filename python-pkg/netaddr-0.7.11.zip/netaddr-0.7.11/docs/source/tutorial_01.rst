============================================
Tutorial 1: IP Addresses, Subnets and Ranges
============================================

.. include:: ../../netaddr/tests/2.x/ip/tutorial.txt

